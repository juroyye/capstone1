package com.stockproj.stockbackend.controller;

import com.stockproj.stockbackend.model.Portfolio;
import com.stockproj.stockbackend.model.Stock;
import com.stockproj.stockbackend.model.User;
import com.stockproj.stockbackend.repository.PortfolioRepository;
import com.stockproj.stockbackend.repository.StockRepository;
import com.stockproj.stockbackend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;


import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/portfolios")
public class PortfolioController {

    private final UserRepository userRepository;
    private final StockRepository stockRepository;
    @Autowired
    private PortfolioRepository portfolioRepository;


    public PortfolioController(UserRepository userRepository, PortfolioRepository portfolioRepository, StockRepository stockRepository) {
        this.userRepository = userRepository;
        this.portfolioRepository = portfolioRepository;
        this.stockRepository = stockRepository;
    }




    @GetMapping
    public List<Portfolio> getAllPortfolios() {
        return portfolioRepository.findAll();
    }


    @GetMapping("/{id}")
    public ResponseEntity<Portfolio> getPortfolioById(@PathVariable Long id) {
        return portfolioRepository.findById(id)
                .map(portfolio -> ResponseEntity.ok().body(portfolio))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/save")
    public ResponseEntity<?> saveStockToUser(@RequestBody Stock stock, Principal principal) {
        try {

            User user = userRepository.findByUsername(principal.getName())
                    .orElseThrow(() -> new RuntimeException("User not found"));

            // Check if the stock already exists in the database
            Stock existingStock = stockRepository.findBySymbol(stock.getSymbol())
                    .orElseGet(() -> stockRepository.save(stock));

            System.out.println("Stock Received: " + stock);



            boolean alreadySaved = portfolioRepository.existsByUserAndStock(user, existingStock);
            if (alreadySaved) {
                return ResponseEntity.ok("Stock already saved to the user's portfolio.");
            }

            // Save the stock to the user's portfolio
            Portfolio portfolio = new Portfolio();
            portfolio.setUser(user);
            portfolio.setStock(existingStock);
            portfolio.setDateAdded(LocalDateTime.now());
            portfolioRepository.save(portfolio);

            return ResponseEntity.ok("Stock saved successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error saving stock: " + e.getMessage());
        }
    }



    @PostMapping
    public Portfolio createPortfolio(@RequestBody Portfolio portfolio) {
        return portfolioRepository.save(portfolio);
    }

    // PUT: Update an existing portfolio
    @PutMapping("/{id}")
    public ResponseEntity<Portfolio> updatePortfolio(@PathVariable Long id, @RequestBody Portfolio portfolioDetails) {
        return portfolioRepository.findById(id).map(portfolio -> {
            portfolio.setName(portfolioDetails.getName());
            portfolio.setStock(portfolioDetails.getStock());
            portfolio.setQuantity(portfolioDetails.getQuantity());
            Portfolio updatedPortfolio = portfolioRepository.save(portfolio);
            return ResponseEntity.ok(updatedPortfolio);
        }).orElse(ResponseEntity.notFound().build());
    }

    // DELETE: Remove a portfolio by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePortfolio(@PathVariable Long id) {
        return portfolioRepository.findById(id).map(portfolio -> {
            portfolioRepository.delete(portfolio);
            return ResponseEntity.ok().build();
        }).orElse(ResponseEntity.notFound().build());
    }
}
