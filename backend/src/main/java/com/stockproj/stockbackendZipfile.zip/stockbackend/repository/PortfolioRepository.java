package com.stockproj.stockbackend.repository;

import com.stockproj.stockbackend.model.Stock;
import com.stockproj.stockbackend.model.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.stockproj.stockbackend.model.Portfolio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PortfolioRepository extends JpaRepository<Portfolio, Long> {
    @Query("SELECT COUNT(p) > 0 FROM Portfolio p WHERE p.user = :user AND p.stock = :stock")
    boolean existsByUserAndStock(@Param("user") User user, @Param("stock") Stock stock);

    @Query("SELECT p FROM Portfolio p WHERE p.user = :user")
    List<Portfolio> findByUser(@Param("user") User user);
}