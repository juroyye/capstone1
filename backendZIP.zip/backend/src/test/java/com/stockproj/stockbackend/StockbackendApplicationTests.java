package com.stockproj.stockbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
