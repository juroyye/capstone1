import '../Sign Up/SignUp.css'
import { Link } from "react-router-dom";
import React from 'react'
import { useState } from 'react';
import Navbar from '../../components/navbar/Navbar'
import axios from 'axios';

const SignUp = () => {
  const loginButtons = [  
     { label: "Home", route: "/" },
    { label: "About", route: "/about" },
    { label: "Login", route: "/login" },
];

const [formData, setFormData] = useState({
  firstName: '',
  lastName: '',
  email: '',
  password: '',
});

// State for handling error/success messages
const [message, setMessage] = useState('');

// Handle input changes
const handleInputChange = (e) => {
  const { name, value } = e.target;
  setFormData((prev) => ({
    ...prev,
    [name]: value,
  }));
};


const handleSubmit = async (e) => {
  e.preventDefault();
  try {
   
    const response = await axios.post('http://localhost:8080/api/signup', formData);
    setMessage('Sign up successful! Please log in.');
  } catch (error) {
    console.error('Error signing up:', error);
    setMessage('Error signing up. Please try again.');
  }
};

  return (
    <div className='signup-page'>
        
        <Navbar buttons={loginButtons}/>

    <div className='loginBod'> 
      
      <div class="login-container">
  <form class="login-form" onSubmit={handleSubmit}>
    <h3>Sign Up</h3>
    <h6>10,000+ stocks at your fingertips</h6>
    <div class="form-group">
      <input 
      type="text" 
      name='firstName'
      placeholder="First Name"
      required 
      value={formData.firstName}
      onChange={handleInputChange}/>
    </div>

    <div class="form-group">
      <input 
      type="text" 
      name='lastName'
      placeholder="Last Name" 
      value={formData.lastName}
      onChange={handleInputChange}
      required />
    </div>

    <div class="form-group">
      <input
       type="text" 
       name='email'
      placeholder="Email" 
      required
      value={formData.email}
      onChange={handleInputChange} 
      />
    </div>


    <div class="form-group">
      <input 
      type="password" 
      name='password'
      placeholder="Password" 
      required 
      value={formData.password}
      onChange={handleInputChange}/>
    </div>

    <button type="submit" className='btnsignup'>Sign Up</button>
    <p className="signup-text">
  Have an account? <Link to="/login" className='signup-link'>Login</Link>
</p>
{message && <p className="message">{message}</p>}
  </form>
</div>
    </div>
    </div>
  )
}

export default SignUp;