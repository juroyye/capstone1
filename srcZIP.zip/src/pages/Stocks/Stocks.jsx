import '../Stocks/Stocks.css'

import React from 'react'

const Stocks = () => {
  return (
    <div>Stocks</div>
  )
}

export default Stocks;